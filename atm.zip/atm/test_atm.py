import unittest
import atm


class TestAtm(unittest.TestCase):
    def test_note5(self):
        self.assertEqual(atm.amount(atm.note5), 5)